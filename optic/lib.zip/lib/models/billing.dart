class Invoice {
  final String id;
  final String patientId;
  final DateTime date;
  final double amount;
  final String status; // paid, pending, cancelled

  Invoice({
    required this.id,
    required this.patientId,
    required this.date,
    required this.amount,
    required this.status,
  });
}
