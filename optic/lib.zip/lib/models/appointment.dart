class Appointment {
  final String id;
  final String patientId;
  final DateTime date;
  final String doctor;
  final String reason;
  final String status; // scheduled, completed, cancelled

  Appointment({
    required this.id,
    required this.patientId,
    required this.date,
    required this.doctor,
    required this.reason,
    required this.status,
  });
}
