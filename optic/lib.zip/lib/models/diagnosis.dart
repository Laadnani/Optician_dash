class Diagnosis {
  final String id;
  final String patientId;
  final DateTime date;
  final String icdCode;
  final String description;

  Diagnosis({
    required this.id,
    required this.patientId,
    required this.date,
    required this.icdCode,
    required this.description,
  });
}
