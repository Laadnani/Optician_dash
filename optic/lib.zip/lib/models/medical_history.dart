class MedicalHistory {
  final String id;
  final String patientId;
  final List<String> conditions;
  final List<String> surgeries;
  final List<String> familyHistory;
  final String notes;

  MedicalHistory({
    required this.id,
    required this.patientId,
    required this.conditions,
    required this.surgeries,
    required this.familyHistory,
    required this.notes,
  });
}
