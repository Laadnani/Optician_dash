class Patient {
  final String id;
  final String fileNumber;
  final String nationalId;
  final String firstName;
  final String lastName;
  final DateTime dob;
  final String gender;
  final String bloodGroup;
  final String phone;
  final String email;
  final String insurance;

  Patient({
    required this.id,
    required this.fileNumber,
    required this.nationalId,
    required this.firstName,
    required this.lastName,
    required this.dob,
    required this.gender,
    required this.bloodGroup,
    required this.phone,
    required this.email,
    required this.insurance,
  });
}
