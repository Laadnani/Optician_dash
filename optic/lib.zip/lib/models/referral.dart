class Referral {
  final String id;
  final String patientId;
  final String referredTo;
  final String reason;
  final DateTime date;

  Referral({
    required this.id,
    required this.patientId,
    required this.referredTo,
    required this.reason,
    required this.date,
  });
}
