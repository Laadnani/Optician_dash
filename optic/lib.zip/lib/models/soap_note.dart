class SoapNote {
  final String id;
  final String patientId;
  final DateTime date;
  final String subjective;
  final String objective;
  final String assessment;
  final String plan;

  SoapNote({
    required this.id,
    required this.patientId,
    required this.date,
    required this.subjective,
    required this.objective,
    required this.assessment,
    required this.plan,
  });
}
