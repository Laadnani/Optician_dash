class Prescription {
  final String id;
  final String patientId;
  final DateTime date;
  final List<String> medications;
  final String instructions;

  Prescription({
    required this.id,
    required this.patientId,
    required this.date,
    required this.medications,
    required this.instructions,
  });
}
