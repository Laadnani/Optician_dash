/// What kind of record generated this task — drives the icon/color in
/// [PendingTasksPanel] and (eventually) which detail screen tapping it
/// should open. Add a case here whenever a new source model needs to
/// surface "needs attention" items; the compiler will then flag every
/// switch (in the panel, in any factory below) that needs a new case too.
enum PendingTaskKind { labResult, imagingResult, referral, lowStock, signature }

/// A single "needs your attention" item on the dashboard. Deliberately
/// generic — it does NOT hold a `LabOrder`/`ImagingOrder`/etc. directly,
/// just a display-ready `title`/`subtitle` plus enough identity
/// (`sourceId`, `patientId`) to navigate back to the real record. This is
/// what lets any model "produce" a pending task the same way any model can
/// carry a `patientId` to reference a `Patient` — the model that generates
/// it (lab order, imaging order, referral, inventory, signature request)
/// doesn't need to know anything about how the dashboard displays it.
class PendingTask {
  final String id;
  final String title;
  final String subtitle;
  final PendingTaskKind kind;

  /// id of the record this task is about (e.g. `LabOrder.id`), so tapping
  /// the task can navigate straight to it once that wiring exists.
  final String sourceId;

  /// Patient this task concerns, if any (inventory/low-stock tasks won't
  /// have one).
  final String? patientId;

  const PendingTask({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.kind,
    required this.sourceId,
    this.patientId,
  });

  // ---------------------------------------------------------------------
  // Factory constructors — one per source model, so e.g.
  // `PendingTask.fromLabOrder(order, patient)` is the only place that
  // knows how to turn a LabOrder into a dashboard task.
  //
  // NOT WRITTEN YET: I don't have lab_order.dart / imaging_order.dart /
  // referral.dart / inventory.dart / digital_signature.dart's real field
  // shapes — guessing them would repeat the same mistake `Appointment`'s
  // `duration`/`type` fields did earlier (invented fields that didn't
  // exist). Share those models and I'll fill these in for real, e.g.:
  //
  //   factory PendingTask.fromLabOrder(LabOrder order, Patient patient) {
  //     return PendingTask(
  //       id: 'lab-${order.id}',
  //       title: '...',
  //       subtitle: '...',
  //       kind: PendingTaskKind.labResult,
  //       sourceId: order.id,
  //       patientId: patient.id,
  //     );
  //   }
  // ---------------------------------------------------------------------
}
