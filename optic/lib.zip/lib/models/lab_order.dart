class LabOrder {
  final String id;
  final String patientId;
  final DateTime orderDate;
  final String testName;
  final String status; // pending, completed

  LabOrder({
    required this.id,
    required this.patientId,
    required this.orderDate,
    required this.testName,
    required this.status,
  });
}
