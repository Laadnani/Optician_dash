class DigitalSignature {
  final String id;
  final String doctorId;
  final String patientId;
  final DateTime signedAt;
  final String signatureData; // base64 or file path

  DigitalSignature({
    required this.id,
    required this.doctorId,
    required this.patientId,
    required this.signedAt,
    required this.signatureData,
  });
}
