class Insurance {
  final String id;
  final String patientId;
  final String provider;
  final String policyNumber;
  final DateTime validUntil;

  Insurance({
    required this.id,
    required this.patientId,
    required this.provider,
    required this.policyNumber,
    required this.validUntil,
  });
}
