class DocumentRecord {
  final String id;
  final String patientId;
  final String type; // report, scan, consent
  final String filePath;
  final DateTime uploadedAt;

  DocumentRecord({
    required this.id,
    required this.patientId,
    required this.type,
    required this.filePath,
    required this.uploadedAt,
  });
}
