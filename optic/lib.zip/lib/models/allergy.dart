class Allergy {
  final String id;
  final String patientId;
  final String allergen;
  final String reaction;
  final String severity;

  Allergy({
    required this.id,
    required this.patientId,
    required this.allergen,
    required this.reaction,
    required this.severity,
  });
}
