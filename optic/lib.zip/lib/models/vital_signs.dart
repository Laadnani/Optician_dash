class VitalSign {
  final String id;
  final String patientId;
  final DateTime recordedAt;
  final double? temperature;
  final int? heartRate;
  final int? systolicBP;
  final int? diastolicBP;

  VitalSign({
    required this.id,
    required this.patientId,
    required this.recordedAt,
    this.temperature,
    this.heartRate,
    this.systolicBP,
    this.diastolicBP,
  });
}
