class ImagingOrder {
  final String id;
  final String patientId;
  final DateTime orderDate;
  final String modality; // e.g. OCT, Fundus, MRI
  final String reason;
  final String status; // pending, completed

  ImagingOrder({
    required this.id,
    required this.patientId,
    required this.orderDate,
    required this.modality,
    required this.reason,
    required this.status,
  });
}
