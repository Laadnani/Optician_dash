class EyeExam {
  final String id;
  final String patientId;
  final DateTime examDate;
  final String visualAcuity; // e.g. 20/20, 20/40
  final double sph; // spherical
  final double cyl; // cylindrical
  final int axis;   // axis in degrees
  final String notes;

  EyeExam({
    required this.id,
    required this.patientId,
    required this.examDate,
    required this.visualAcuity,
    required this.sph,
    required this.cyl,
    required this.axis,
    required this.notes,
  });
}
