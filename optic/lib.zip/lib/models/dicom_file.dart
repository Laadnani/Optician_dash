class DicomFile {
  final String id;
  final String patientId;
  final String filePath;
  final DateTime uploadedAt;
  final String modality; // CT, MRI, OCT

  DicomFile({
    required this.id,
    required this.patientId,
    required this.filePath,
    required this.uploadedAt,
    required this.modality,
  });
}
