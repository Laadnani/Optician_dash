class Report {
  final String id;
  final String type; // clinical, financial
  final DateTime generatedAt;
  final String filePath;

  Report({
    required this.id,
    required this.type,
    required this.generatedAt,
    required this.filePath,
  });
}
