class TelemedicineSession {
  final String id;
  final String patientId;
  final String doctorId;
  final DateTime scheduledAt;
  final String platform; // Zoom, Teams, etc.
  final String status; // scheduled, completed

  TelemedicineSession({
    required this.id,
    required this.patientId,
    required this.doctorId,
    required this.scheduledAt,
    required this.platform,
    required this.status,
  });
}
