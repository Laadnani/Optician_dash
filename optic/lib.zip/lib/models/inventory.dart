class InventoryItem {
  final String id;
  final String name;
  final int quantity;
  final String unit;
  final DateTime lastUpdated;

  InventoryItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.unit,
    required this.lastUpdated,
  });
}
  