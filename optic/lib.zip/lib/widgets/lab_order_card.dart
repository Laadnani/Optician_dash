import '../../models/lab_order.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class LabOrderCard extends StatelessWidget {
  final LabOrder order;
  const LabOrderCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Lab Order").semiBold(),
          const SizedBox(height: 8),
          Text("Test: ${order.testName}").muted(),
          Text("Status: ${order.status}").muted(),
          Text("Date: ${order.orderDate}").muted(),
        ],
      ),
    );
  }
}
