import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:provider/provider.dart';
import '../localization/app_strings.dart';
import '../controllers/session_provider.dart';
import '../controllers/theme_controller.dart';

/// A single navigation entry in [AppDrawer].
class DrawerItem {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool selected;

  const DrawerItem({
    required this.label,
    required this.icon,
    required this.onTap,
    this.selected = false,
  });
}

/// Side navigation, themed to match the dashboard's Blue family
/// (`ColorSchemes.darkBlue`/`lightBlue`) — kept deliberately distinct from
/// the app shell's `DefaultColor` family (see `main.dart`), but still
/// responds to `ThemeController.isDarkMode` like everything else.
///
/// Works in two shapes, controlled entirely by [collapsed]:
///  - expanded (280px): brand + labelled nav items — used as the desktop
///    persistent sidebar, and inside the mobile/tablet overlay.
///  - collapsed (72px, icon rail): used only on desktop, when the user
///    clicks the hamburger to shrink the sidebar out of the way.
///
/// [onToggleCollapse] is what the hamburger button (living in this widget's
/// own header) calls — on desktop that flips [collapsed], and inside the
/// mobile/tablet overlay it's wired to close the overlay instead (see
/// `openAppDrawer` below). This widget doesn't know or care which; it just
/// calls the callback.
class AppDrawer extends StatelessWidget {
  final String clinicName;
  final String doctorName;
  final List<DrawerItem> items;
  final VoidCallback? onSignOut;
  final bool collapsed;
  final VoidCallback? onToggleCollapse;

  const AppDrawer({
    super.key,
    // No hardcoded defaults — clinicName/doctorName are data (the signed-in
    // doctor's profile), not UI copy, so they're required here and sourced
    // from your session/profile layer at the call site instead.
    required this.clinicName,
    required this.doctorName,
    required this.items,
    this.onSignOut,
    this.collapsed = false,
    this.onToggleCollapse,
  });

  static const double expandedWidth = 280;
  static const double collapsedWidth = 72;
  static const Duration _animationDuration = Duration(milliseconds: 200);

  @override
  Widget build(BuildContext context) {
    final isDarkMode = context.watch<ThemeController>().isDarkMode;
    final colorScheme = isDarkMode
        ? ColorSchemes.darkBlue
        : ColorSchemes.lightBlue;

    return Theme(
      data: ThemeData(colorScheme: colorScheme, radius: 1.5),
      // AnimatedContainer + clipBehavior: hardEdge is the overflow guard —
      // whatever the width is mid-animation, content that hasn't caught up
      // yet gets clipped to the box instead of painting outside it.
      child: AnimatedContainer(
        duration: _animationDuration,
        curve: Curves.easeInOut,
        width: collapsed ? collapsedWidth : expandedWidth,
        height: double.infinity,
        color: colorScheme.background,
        clipBehavior: Clip.hardEdge,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _header(colorScheme),
              _rule(colorScheme),
              Expanded(
                child: ListView.separated(
                  padding: EdgeInsets.symmetric(
                    vertical: 8,
                    horizontal: collapsed ? 8 : 12,
                  ),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 4),
                  itemBuilder: (context, i) => _DrawerTile(
                    item: items[i],
                    colorScheme: colorScheme,
                    collapsed: collapsed,
                  ),
                ),
              ),
              _rule(colorScheme),
              Padding(
                padding: EdgeInsets.all(collapsed ? 8 : 12),
                child: _DrawerTile(
                  item: DrawerItem(
                    label: AppStrings.sidebarSignOut,
                    icon: Icons.logout_outlined,
                    onTap: onSignOut ?? () {},
                  ),
                  colorScheme: colorScheme,
                  collapsed: collapsed,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(ColorScheme colorScheme) {
    if (collapsed) {
      // Collapsed: just the toggle button, centered — no brand text to
      // fit into 72px, so nothing to overflow.
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: Button(
            style: const ButtonStyle.ghost(),
            onPressed: onToggleCollapse,
            child: const Icon(Icons.menu),
          ),
        ),
      );
    }

    // Expanded: icon avatar (fixed) + text (Expanded, so it's bounded and
    // ellipsizes instead of overflowing) + the toggle button (fixed).
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 8, 16),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: colorScheme.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            alignment: Alignment.center,
            child: Icon(Icons.remove_red_eye_outlined, color: colorScheme.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  clinicName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ).semiBold(),
                Text(
                  doctorName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ).muted(),
              ],
            ),
          ),
          if (onToggleCollapse != null)
            Button(
              style: const ButtonStyle.ghost(),
              onPressed: onToggleCollapse,
              child: const Icon(Icons.menu),
            ),
        ],
      ),
    );
  }

  // A thin 1px rule instead of a Divider widget — avoids guessing whether
  // shadcn_flutter's own divider/separator component is named `Divider`,
  // `Separator`, etc. Guaranteed to compile and match the theme.
  Widget _rule(ColorScheme colorScheme) =>
      Container(height: 1, color: colorScheme.border);
}

class _DrawerTile extends StatelessWidget {
  final DrawerItem item;
  final ColorScheme colorScheme;
  final bool collapsed;

  const _DrawerTile({
    required this.item,
    required this.colorScheme,
    this.collapsed = false,
  });

  @override
  Widget build(BuildContext context) {
    return Button(
      style: item.selected
          ? const ButtonStyle.primary()
          : const ButtonStyle.ghost(),
      onPressed: item.onTap,
      alignment: collapsed ? Alignment.center : Alignment.centerLeft,
      // Collapsed: icon only, no Expanded/Text at all — nothing that could
      // need to shrink or ellipsize, so nothing that can overflow.
      child: collapsed
          ? Icon(item.icon, size: 20)
          : Row(
              children: [
                Icon(item.icon, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
    );
  }
}

// ---------------------------------------------------------------------------
// Presenting the drawer as a mobile/tablet overlay
// ---------------------------------------------------------------------------
//
// Only used on mobile/tablet (see navigation.dart) — the desktop sidebar is
// rendered inline instead, with `collapsed` toggling its width in place.
//
// Uses Flutter's own `Navigator` + `PageRouteBuilder` rather than a guessed
// shadcn_flutter overlay call, so it's guaranteed to compile regardless of
// your installed shadcn_flutter version.

void openAppDrawer(BuildContext context, {required List<DrawerItem> items}) {
  Navigator.of(context).push(
    PageRouteBuilder(
      opaque: false,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.4),
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (routeContext, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerLeft,
          child: AppDrawer(
            clinicName: SessionProvider.clinicName,
            doctorName: SessionProvider.doctorName,
            items: items,
            // Tapping the hamburger inside the open overlay retracts it —
            // there's no "collapsed rail" concept in overlay mode, closing
            // is the equivalent action.
            onToggleCollapse: () => Navigator.of(routeContext).pop(),
          ),
        );
      },
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final offset = Tween<Offset>(
          begin: const Offset(-1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut));
        return SlideTransition(position: offset, child: child);
      },
    ),
  );
}
