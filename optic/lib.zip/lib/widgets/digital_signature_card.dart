import '../../models/digital_signature.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class DigitalSignatureCard extends StatelessWidget {
  final DigitalSignature signature;
  const DigitalSignatureCard({super.key, required this.signature});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Digital Signature").semiBold(),
          const SizedBox(height: 8),
          Text("Doctor ID: ${signature.doctorId}").muted(),
          Text("Patient ID: ${signature.patientId}").muted(),
          Text("Signed At: ${signature.signedAt}").muted(),
        ],
      ),
    );
  }
}
