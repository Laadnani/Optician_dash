import '../../models/soap_note.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class SoapNoteCard extends StatelessWidget {
  final SoapNote note;
  const SoapNoteCard({super.key, required this.note});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("SOAP Note").semiBold(),
          const SizedBox(height: 8),
          Text("Subjective: ${note.subjective}").muted(),
          Text("Objective: ${note.objective}").muted(),
          Text("Assessment: ${note.assessment}").muted(),
          Text("Plan: ${note.plan}").muted(),
        ],
      ),
    );
  }
}
