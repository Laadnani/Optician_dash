import '../../models/insurance.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class InsuranceCard extends StatelessWidget {
  final Insurance insurance;
  const InsuranceCard({super.key, required this.insurance});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Insurance").semiBold(),
          const SizedBox(height: 8),
          Text("Provider: ${insurance.provider}").muted(),
          Text("Policy #: ${insurance.policyNumber}").muted(),
          Text("Valid Until: ${insurance.validUntil}").muted(),
        ],
      ),
    );
  }
}
