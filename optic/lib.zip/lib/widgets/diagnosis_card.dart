import '../../models/diagnosis.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class DiagnosisCard extends StatelessWidget {
  final Diagnosis diagnosis;
  const DiagnosisCard({super.key, required this.diagnosis});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Diagnosis").semiBold(),
          const SizedBox(height: 8),
          Text("ICD-10 Code: ${diagnosis.icdCode}").muted(),
          Text("Description: ${diagnosis.description}").muted(),
          Text("Date: ${diagnosis.date}").muted(),
        ],
      ),
    );
  }
}
