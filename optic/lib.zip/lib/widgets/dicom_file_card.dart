import '../../models/dicom_file.dart';

import 'package:shadcn_flutter/shadcn_flutter.dart';

class DicomFileCard extends StatelessWidget {
  final DicomFile dicom;
  const DicomFileCard({super.key, required this.dicom});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("DICOM File").semiBold(),
          const SizedBox(height: 8),
          Text("Modality: ${dicom.modality}").muted(),
          Text("File: ${dicom.filePath}").muted(),
          Text("Uploaded: ${dicom.uploadedAt}").muted(),
        ],
      ),
    );
  }
}
