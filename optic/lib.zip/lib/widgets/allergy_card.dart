import '../../models/allergy.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class AllergyCard extends StatelessWidget {
  final Allergy allergy;
  const AllergyCard({super.key, required this.allergy});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Allergy").semiBold(),
          const SizedBox(height: 8),
          Text("Allergen: ${allergy.allergen}").muted(),
          Text("Reaction: ${allergy.reaction}").muted(),
          Text("Severity: ${allergy.severity}").muted(),
        ],
      ),
    );
  }
}
