import '../../models/billing.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class BillingCard extends StatelessWidget {
  final Invoice invoice;
  const BillingCard({super.key, required this.invoice});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Invoice #${invoice.id}"),
          const SizedBox(height: 8),
          Text("Amount: ${invoice.amount} MAD"),
          Text("Status: ${invoice.status}"),
          Text("Date: ${invoice.date}"),
        ],
      ),
    );
  }
}
