import '../../models/report.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class ReportCard extends StatelessWidget {
  final Report report;
  const ReportCard({super.key, required this.report});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Report").semiBold(),
          const SizedBox(height: 8),
          Text("Type: ${report.type}").muted(),
          Text("Generated At: ${report.generatedAt}").muted(),
          Text("File: ${report.filePath}").muted(),
        ],
      ),
    );
  }
}
