import '../../models/patient.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class PatientProfileCard extends StatelessWidget {
  final Patient patient;
  const PatientProfileCard({super.key, required this.patient});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("${patient.firstName} ${patient.lastName}").semiBold(),
          const SizedBox(height: 8),
          Text("DOB: ${patient.dob.toLocal().toString().split(' ')[0]}").muted(),
          Text("Gender: ${patient.gender}").muted(),
          Text("Blood Group: ${patient.bloodGroup}").muted(),
          Text("Insurance: ${patient.insurance.isEmpty ? 'None' : patient.insurance}").muted(),
        ],
      ),
    );
  }
}
