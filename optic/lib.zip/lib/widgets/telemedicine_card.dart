import '../../models/telemedicine.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class TelemedicineCard extends StatelessWidget {
  final TelemedicineSession session;
  const TelemedicineCard({super.key, required this.session});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Telemedicine Session").semiBold(),
          const SizedBox(height: 8),
          Text("Doctor ID: ${session.doctorId}").muted(),
          Text("Platform: ${session.platform}").muted(),
          Text("Status: ${session.status}").muted(),
          Text("Scheduled At: ${session.scheduledAt}").muted(),
        ],
      ),
    );
  }
}
