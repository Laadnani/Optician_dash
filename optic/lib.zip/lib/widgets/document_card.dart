import '../../models/document.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class DocumentCard extends StatelessWidget {
  final DocumentRecord document;
  const DocumentCard({super.key, required this.document});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Document").semiBold(),
          const SizedBox(height: 8),
          Text("Type: ${document.type}").muted(),
          Text("File: ${document.filePath}").muted(),
          Text("Uploaded: ${document.uploadedAt}").muted(),
        ],
      ),
    );
  }
}
