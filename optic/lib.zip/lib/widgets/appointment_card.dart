
import '../../models/appointment.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class AppointmentCard extends StatelessWidget {
  final Appointment appointment;
  const AppointmentCard({super.key, required this.appointment});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Appointment with ${appointment.doctor}"),
          const SizedBox(height: 8),
          Text("Date: ${appointment.date}"),
          Text("Reason: ${appointment.reason}"),
          Text("Status: ${appointment.status}"),
        ],
      ),
    );
  }
}
