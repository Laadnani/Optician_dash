import '../../models/referral.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class ReferralCard extends StatelessWidget {
  final Referral referral;
  const ReferralCard({super.key, required this.referral});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Referral").semiBold(),
          const SizedBox(height: 8),
          Text("Referred To: ${referral.referredTo}").muted(),
          Text("Reason: ${referral.reason}").muted(),
          Text("Date: ${referral.date}").muted(),
        ],
      ),
    );
  }
}
