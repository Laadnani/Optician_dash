import '../../models/prescription.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class PrescriptionCard extends StatelessWidget {
  final Prescription prescription;
  const PrescriptionCard({super.key, required this.prescription});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Prescription").semiBold(),
          const SizedBox(height: 8),
          Text("Date: ${prescription.date}").muted(),
          ...prescription.medications.map((med) => Text("- $med")).toList(),
          const SizedBox(height: 8),
          Text("Instructions: ${prescription.instructions}").muted(),
        ],
      ),
    );
  }
}
