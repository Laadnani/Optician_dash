import '../../models/inventory.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class InventoryCard extends StatelessWidget {
  final InventoryItem item;
  const InventoryCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Inventory Item").semiBold(),
          const SizedBox(height: 8),
          Text("Name: ${item.name}").muted(),
          Text("Quantity: ${item.quantity} ${item.unit}").muted(),
          Text("Last Updated: ${item.lastUpdated}").muted(),
        ],
      ),
    );
  }
}
