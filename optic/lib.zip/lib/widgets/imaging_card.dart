import '../../models/imaging_order.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class ImagingOrderCard extends StatelessWidget {
  final ImagingOrder order;
  const ImagingOrderCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Imaging Order").semiBold(),
          const SizedBox(height: 8),
          Text("Modality: ${order.modality}").muted(),
          Text("Reason: ${order.reason}").muted(),
          Text("Status: ${order.status}").muted(),
          Text("Date: ${order.orderDate}").muted(),
        ],
      ),
    );
  }
}
