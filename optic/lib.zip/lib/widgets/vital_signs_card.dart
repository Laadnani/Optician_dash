import '../../models/vital_signs.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class VitalSignsCard extends StatelessWidget {
  final VitalSign vital;
  const VitalSignsCard({super.key, required this.vital});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Vital Signs").semiBold(),
          const SizedBox(height: 8),
          Text("Temperature: ${vital.temperature} °C").muted(),
          Text("Heart Rate: ${vital.heartRate} bpm").muted(),
          Text("BP: ${vital.systolicBP}/${vital.diastolicBP} mmHg").muted(),
        ],
      ),
    );
  }
}
