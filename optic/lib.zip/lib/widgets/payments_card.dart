import '../../models/payments.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class PaymentsCard extends StatelessWidget {
  final Payment payment;
  const PaymentsCard({super.key, required this.payment});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Payment").semiBold(),
          const SizedBox(height: 8),
          Text("Amount: ${payment.amount} MAD").muted(),
          Text("Method: ${payment.method}").muted(),
          Text("Date: ${payment.date}").muted(),
        ],
      ),
    );
  }
}
