import '../../models/eye_exam.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class EyeExamCard extends StatelessWidget {
  final EyeExam exam;
  const EyeExamCard({super.key, required this.exam});

  @override
  Widget build(BuildContext context) {
    return Card(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Eye Exam").semiBold(),
          const SizedBox(height: 8),
          Text("Visual Acuity: ${exam.visualAcuity}").muted(),
          Text("SPH: ${exam.sph}, CYL: ${exam.cyl}, AXIS: ${exam.axis}").muted(),
          Text("Notes: ${exam.notes}").muted(),
        ],
      ),
    );
  }
}
