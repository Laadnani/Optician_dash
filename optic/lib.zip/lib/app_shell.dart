import 'dart:async';

import 'package:flutter/material.dart' as material;
import 'package:optic/helpers/breakpoint.dart';
import 'package:provider/provider.dart';
import 'package:optic/widgets/sidebar.dart';
import '../controllers/session_provider.dart';
import 'package:optic/helpers/nav_items.dart';
import 'package:optic/controllers/theme_controller.dart';
import 'package:optic/responsive.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';


/// Everything a screen needs around its own content: the persistent
/// desktop sidebar (collapsible via its own hamburger), the mobile/tablet
/// overlay drawer (opened via a slim top hamburger bar), and the
/// resize-settle loading state — all in one place, so every screen gets
/// this behavior by wrapping itself in [AppShell] instead of re-building it.
///
/// Usage:
/// ```dart
/// return AppShell(
///   navItems: (context) => buildAppNavItems(context, 'Dashboard'),
///   bodyBuilder: (context, breakpoint) => MyScreenBody(breakpoint: breakpoint),
/// );
/// ```
class AppShell extends StatefulWidget {
  final List<DrawerItem> Function(BuildContext context) navItems;
  final Widget Function(BuildContext context, Breakpoint breakpoint)
  bodyBuilder;

  const AppShell({super.key, required this.navItems, required this.bodyBuilder});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  // Desktop-only: whether the persistent sidebar is full width (with
  // labels) or collapsed to an icon rail.
  bool _sidebarExpanded = true;

  // --- Resize-settle handling -------------------------------------------
  // While the window/viewport width is actively changing, we don't want to
  // keep re-laying-out the full screen on every intermediate width. Instead
  // show a loading state and only rebuild once width stops changing for a
  // short debounce window, "landing" on whichever breakpoint it settles into.
  double? _lastObservedWidth;
  bool _isSettlingLayout = false;
  Timer? _resizeDebounce;

  static const _resizeSettleDelay = Duration(milliseconds: 220);

  void _reportWidth(double width) {
    final isFirstObservation = _lastObservedWidth == null;
    final changed =
        _lastObservedWidth == null ||
        (width - _lastObservedWidth!).abs() > 0.5;
    if (!changed) return;

    _lastObservedWidth = width;
    _resizeDebounce?.cancel();

    if (!isFirstObservation && !_isSettlingLayout) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !_isSettlingLayout) {
          setState(() => _isSettlingLayout = true);
        }
      });
    }

    _resizeDebounce = Timer(_resizeSettleDelay, () {
      if (mounted) setState(() => _isSettlingLayout = false);
    });
  }

  @override
  void dispose() {
    _resizeDebounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = context.watch<ThemeController>().isDarkMode;
    return Scaffold(
      backgroundColor: isDarkMode
          ? ColorSchemes.darkBlue.background
          : ColorSchemes.lightBlue.background,
      child: LayoutBuilder(
        builder: (context, constraints) {
          _reportWidth(constraints.maxWidth);

          if (_isSettlingLayout) {
            return const Center(child: material.CircularProgressIndicator());
          }

          final mobile = Responsive.isMobile(context);
          final tablet = Responsive.isTablet(context);
          final desktop = Responsive.isDesktop(context);
          final breakpoint = resolveBreakpoint(
            mobile: mobile,
            tablet: tablet,
            desktop: desktop,
          );
          final navItems = widget.navItems(context);

          if (breakpoint != Breakpoint.desktop) {
            // Mobile/tablet: no inline sidebar — a slim top bar with a
            // hamburger opens it as an overlay instead. Each screen's own
            // body starts right below it.
            return SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                    child: Row(
                      children: [
                        Button(
                          style: const ButtonStyle.ghost(),
                          onPressed: () =>
                              openAppDrawer(context, items: navItems),
                          child: const Icon(Icons.menu),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: widget.bodyBuilder(context, breakpoint),
                  ),
                ],
              ),
            );
          }

          // Desktop: sidebar sits inline, permanently, toggling between
          // full width and an icon rail via its own hamburger button.
          return Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppDrawer(
                clinicName: SessionProvider.clinicName,
                doctorName: SessionProvider.doctorName,
                items: navItems,
                collapsed: !_sidebarExpanded,
                onToggleCollapse: () =>
                    setState(() => _sidebarExpanded = !_sidebarExpanded),
              ),
              Expanded(
                child: SafeArea(
                  child: widget.bodyBuilder(context, breakpoint),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
