import 'package:optic/app_shell.dart';
import 'package:optic/helpers/breakpoint.dart';
import 'package:optic/helpers/dashboard_sections.dart';
import 'package:optic/helpers/kpi_row.dart';
import 'package:optic/helpers/nav_items.dart';
import 'package:optic/helpers/pending_tasks_panel.dart';
import 'package:optic/helpers/quick_actions_bar.dart';
import 'package:optic/models/pending_task.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:flutter/material.dart' as material;
import 'package:provider/provider.dart';
import 'package:optic/screens/appointments_column.dart';
import 'package:optic/screens/calendar_column.dart';
import 'package:optic/screens/header.dart' as header;
import 'package:optic/localization/app_strings.dart';
import 'package:optic/data/data_provider.dart';
import 'package:optic/controllers/theme_controller.dart';
import 'package:optic/data/dashboard_repository.dart';
import '../models/dashboard_appointment.dart';

/// Doctor-facing dashboard: pick a day on the calendar, see that day's
/// appointment timeline, keep an eye on pending clinical tasks, and jump
/// into common actions.
///
/// Stateless on purpose — all the sidebar/drawer/resize behavior lives in
/// [AppShell] (shared by every screen), and this widget just supplies the
/// dashboard's content to it. Data comes from your real [DataProvider] via
/// [ProviderDashboardRepository] — `context.watch<DataProvider>()` means
/// this rebuilds (and re-fetches) whenever `DataProvider.notifyListeners()`
/// fires, e.g. after `addAppointment(...)`.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();
    final repository = ProviderDashboardRepository(dataProvider);

    return AppShell(
      navItems: (context) => buildAppNavItems(context, NavRoute.dashboard),
      bodyBuilder: (context, breakpoint) => _DashboardBody(
        breakpoint: breakpoint,
        repository: repository,
      ),
    );
  }
}

class _DashboardBody extends StatefulWidget {
  final Breakpoint breakpoint;
  final DashboardRepository repository;

  const _DashboardBody({required this.breakpoint, required this.repository});

  @override
  State<_DashboardBody> createState() => _DashboardBodyState();
}

class _DashboardBodyState extends State<_DashboardBody> {
  DateTime _selectedDate = DateTime.now();
  List<DashboardAppointment> _allAppointments = const [];
  List<PendingTask> _pendingTasks = const [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void didUpdateWidget(covariant _DashboardBody oldWidget) {
    super.didUpdateWidget(oldWidget);
    // A new repository instance means DataProvider notified — re-fetch so
    // e.g. DataProvider.addAppointment(...) shows up without navigating
    // away and back.
    if (oldWidget.repository != widget.repository) {
      _loadData();
    }
  }

  Future<void> _loadData() async {
    final appointments = await widget.repository.fetchAppointments();
    final pendingTasks = await widget.repository.fetchPendingTasks();
    if (!mounted) return;
    setState(() {
      _allAppointments = appointments;
      _pendingTasks = pendingTasks;
      _isLoading = false;
    });
  }

  List<DashboardAppointment> get _todaysAppointments {
    final list =
        _allAppointments
            .where(
              (a) => DashboardAppointment.isSameDay(a.start, _selectedDate),
            )
            .toList()
          ..sort((a, b) => a.start.compareTo(b.start));
    return list;
  }

  Widget _buildQuickActions() {
    return QuickActionsBar(
      actions: [
        QuickAction(
          label: AppStrings.quickActionNewAppointment,
          icon: Icons.event_available_outlined,
          onTap: () {},
        ),
        QuickAction(
          label: AppStrings.quickActionNewPatient,
          icon: Icons.person_add_alt_outlined,
          onTap: () {},
        ),
        QuickAction(
          label: AppStrings.quickActionStartTelemedicine,
          icon: Icons.videocam_outlined,
          onTap: () {},
        ),
        QuickAction(
          label: AppStrings.quickActionWritePrescription,
          icon: Icons.receipt_long_outlined,
          onTap: () {},
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: material.CircularProgressIndicator());
    }

    final desktop = widget.breakpoint == Breakpoint.desktop;
    final isDarkMode = context.watch<ThemeController>().isDarkMode;
    final isSameDayAsToday = DashboardAppointment.isSameDay(
      _selectedDate,
      DateTime.now(),
    );
    final todays = _todaysAppointments;
    final completed = todays
        .where((a) => a.status == AppointmentStatus.completed)
        .length;
    final scheduled = todays
        .where((a) => a.status == AppointmentStatus.scheduled)
        .length;
    final cancelled = todays
        .where((a) => a.status == AppointmentStatus.cancelled)
        .length;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          header.Header(
            theme: ThemeData(
              colorScheme: isDarkMode
                  ? ColorSchemes.darkBlue
                  : ColorSchemes.lightBlue,
              radius: 1.5,
            ),
          ),
          const SizedBox(height: 20),
          _buildQuickActions(),
          const SizedBox(height: 20),
          DashboardKpiRow(
            desktop: desktop,
            todaysCount: todays.length,
            completed: completed,
            scheduled: scheduled,
            cancelled: cancelled,
          ),
          const SizedBox(height: 20),
          DashboardMainSection(
            breakpoint: widget.breakpoint,
            calendarCard: CalendarColumn(
              selectedDate: _selectedDate,
              appointments: _allAppointments,
              onDateSelected: (d) => setState(() => _selectedDate = d),
            ),
            appointmentsCard: AppointmentsColumn(
              selectedDate: _selectedDate,
              isToday: isSameDayAsToday,
              appointments: todays,
            ),
            pendingTasksCard: PendingTasksPanel(
              title: AppStrings.pendingTasksTitle,
              items: _pendingTasks,
              onSeeAll: () {},
            ),
          ),
        ],
      ),
    );
  }
}
