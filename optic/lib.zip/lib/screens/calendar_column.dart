import 'package:optic/models/dashboard_appointment.dart';
import 'package:optic/helpers/mini_month_calendar.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class CalendarColumn extends StatelessWidget {
  final DateTime selectedDate;
  final List<DashboardAppointment> appointments;
  final ValueChanged<DateTime> onDateSelected;

  const CalendarColumn({
    required this.selectedDate,
    required this.appointments,
    required this.onDateSelected,
  });

  @override
  Widget build(BuildContext context) {
    final datesWithAppointments = appointments
        .map((a) => DateTime(a.start.year, a.start.month, a.start.day))
        .toSet();

    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
       // padding: const EdgeInsets.all(25),
        children:[ MiniMonthCalendar(
          selectedDate: selectedDate,
          onDateSelected: onDateSelected,
          datesWithAppointments: datesWithAppointments,
        ),]
      ),
    );
  }
}
