import 'package:flutter/material.dart' as material;
import 'package:optic/app_shell.dart';
import 'package:optic/helpers/nav_items.dart';
import 'package:provider/provider.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:optic/controllers/theme_controller.dart';
import 'package:optic/localization/app_strings.dart';

/// A named color family — one `light`/`dark` pair. This is the *complete*
/// list from shadcn_flutter's real `ColorSchemes` source (confirmed, not
/// guessed): exactly 8 families, each with a `light{Name}`/`dark{Name}`
/// const. No "Slate" — that appeared in an earlier doc example but doesn't
/// actually exist in the package.
class _ColorFamily {
  final String name;
  final ColorScheme light;
  final ColorScheme dark;
  const _ColorFamily(this.name, this.light, this.dark);
}

const List<_ColorFamily> _colorFamilies = [
  _ColorFamily('Default', ColorSchemes.lightDefaultColor, ColorSchemes.darkDefaultColor),
  _ColorFamily('Blue', ColorSchemes.lightBlue, ColorSchemes.darkBlue),
  _ColorFamily('Green', ColorSchemes.lightGreen, ColorSchemes.darkGreen),
  _ColorFamily('Orange', ColorSchemes.lightOrange, ColorSchemes.darkOrange),
  _ColorFamily('Red', ColorSchemes.lightRed, ColorSchemes.darkRed),
  _ColorFamily('Rose', ColorSchemes.lightRose, ColorSchemes.darkRose),
  _ColorFamily('Violet', ColorSchemes.lightViolet, ColorSchemes.darkViolet),
  _ColorFamily('Yellow', ColorSchemes.lightYellow, ColorSchemes.darkYellow),
];

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      navItems: (context) => buildAppNavItems(context, NavRoute.settings),
      bodyBuilder: (context, breakpoint) => const _SettingsBody(),
    );
  }
}

class _SettingsBody extends StatefulWidget {
  const _SettingsBody();

  @override
  State<_SettingsBody> createState() => _SettingsBodyState();
}

class _SettingsBodyState extends State<_SettingsBody> {
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AppStrings.navSettings).large().bold(),
          const SizedBox(height: 20),
          Tabs(
            index: _tabIndex,
            onChanged: (value) => setState(() => _tabIndex = value),
            children: const [
              TabItem(child: Text(AppStrings.settingsAppearanceTab)),
              TabItem(child: Text(AppStrings.settingsAccountTab)),
              TabItem(child: Text(AppStrings.settingsNotificationsTab)),
            ],
          ),
          const SizedBox(height: 20),
          IndexedStack(
            index: _tabIndex,
            children: const [
              _AppearanceTab(),
              _ComingSoonTab(title: AppStrings.settingsAccountTab),
              _ComingSoonTab(title: AppStrings.settingsNotificationsTab),
            ],
          ),
        ],
      ),
    );
  }
}

class _ComingSoonTab extends StatelessWidget {
  final String title;
  const _ComingSoonTab({required this.title});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title).semiBold(),
              const SizedBox(height: 4),
              const Text(AppStrings.placeholderComingSoon).muted(),
            ],
          ),
        ),
      ),
    );
  }
}

/// The actual theme-customization panel. Holds a local draft of every
/// confirmed `ThemeData` field — colorScheme, radius, scaling,
/// surfaceOpacity, surfaceBlur, typography — with a live preview.
///
/// Partially wired: your real `ThemeController` only tracks `isDarkMode`
/// (a boolean), so the dark-mode switch here is LIVE — toggling it calls
/// `ThemeController.setTheme(...)` via Provider and re-themes the whole
/// app immediately (see `main.dart`). Color family, radius, scaling,
/// surface opacity/blur, and typography have nowhere app-wide to live yet
/// — `ThemeController` doesn't track them — so those stay preview-only
/// until it's extended (or a richer theme-preferences store replaces it).
class _AppearanceTab extends StatefulWidget {
  const _AppearanceTab();

  @override
  State<_AppearanceTab> createState() => _AppearanceTabState();
}

class _AppearanceTabState extends State<_AppearanceTab> {
  int _familyIndex = 0;
  double _radius = 1.5;
  double _scaling = 1.0;
  double _surfaceOpacity = 0.8;
  double _surfaceBlur = 8.0;
  bool _useGeistTypography = false;

  ThemeData _draftTheme(bool isDarkMode) {
    final family = _colorFamilies[_familyIndex];
    return ThemeData(
      colorScheme: isDarkMode ? family.dark : family.light,
      radius: _radius,
      scaling: _scaling,
      surfaceOpacity: _surfaceOpacity,
      surfaceBlur: _surfaceBlur,
      typography: _useGeistTypography ? const Typography.geist() : Typography.geist(),
    );
  }

  Widget _sliderRow({
    required String label,
    required double value,
    required double min,
    required double max,
    required ValueChanged<double> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          SizedBox(
            width: 140,
            child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          Expanded(
            // Using Flutter's own Slider (aliased `material`) rather than
            // guessing shadcn_flutter's slider API/param names — same
            // reasoning as the CircularProgressIndicator used elsewhere in
            // this app.
            child: material.Slider(
              value: value,
              min: min,
              max: max,
              onChanged: onChanged,
            ),
          ),
          SizedBox(
            width: 44,
            child: Text(
              value.toStringAsFixed(2),
              textAlign: TextAlign.right,
            ).muted(),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Live, real state — toggling this actually calls your ThemeController
    // and re-themes the whole app immediately (see main.dart), unlike the
    // rest of this panel which is preview-only for now.
    final themeController = context.watch<ThemeController>();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // --- Controls ------------------------------------------------
        Expanded(
          flex: 3,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- Dark mode: LIVE, wired to the real ThemeController.
                  Row(
                    children: [
                      material.Switch(
                        value: themeController.isDarkMode,
                        onChanged: (v) =>
                            context.read<ThemeController>().setTheme(v),
                      ),
                      const SizedBox(width: 8),
                      Text(AppStrings.settingsDarkModeLabel),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(AppStrings.settingsColorSchemeLabel).semiBold(),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (var i = 0; i < _colorFamilies.length; i++)
                        Button(
                          style: i == _familyIndex
                              ? const ButtonStyle.primary()
                              : const ButtonStyle.ghost(),
                          onPressed: () => setState(() => _familyIndex = i),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: themeController.isDarkMode
                                      ? _colorFamilies[i].dark.primary
                                      : _colorFamilies[i].light.primary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(_colorFamilies[i].name),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _sliderRow(
                    label: AppStrings.settingsRadiusLabel,
                    value: _radius,
                    min: 0,
                    max: 2,
                    onChanged: (v) => setState(() => _radius = v),
                  ),
                  _sliderRow(
                    label: AppStrings.settingsScalingLabel,
                    value: _scaling,
                    min: 0.6,
                    max: 1.5,
                    onChanged: (v) => setState(() => _scaling = v),
                  ),
                  _sliderRow(
                    label: AppStrings.settingsSurfaceOpacityLabel,
                    value: _surfaceOpacity,
                    min: 0,
                    max: 1,
                    onChanged: (v) => setState(() => _surfaceOpacity = v),
                  ),
                  _sliderRow(
                    label: AppStrings.settingsSurfaceBlurLabel,
                    value: _surfaceBlur,
                    min: 0,
                    max: 20,
                    onChanged: (v) => setState(() => _surfaceBlur = v),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      material.Switch(
                        value: _useGeistTypography,
                        onChanged: (v) =>
                            setState(() => _useGeistTypography = v),
                      ),
                      const SizedBox(width: 8),
                      Text(AppStrings.settingsTypographyLabel),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    AppStrings.settingsPreviewOnlyNote,
                    maxLines: 2,
                  ).muted().small(),
                  const SizedBox(height: 12),
                  Button(
                    style: const ButtonStyle.primary(),
                    // Color family / radius / scaling / surface / typography
                    // have nowhere to live app-wide yet — ThemeController
                    // only tracks isDarkMode. Extend it (or introduce a
                    // richer theme-preferences store) to make this button
                    // do more than preview.
                    onPressed: () {},
                    child: const Text(AppStrings.settingsApplyButton),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        // --- Live preview ----------------------------------------------
        Expanded(
          flex: 2,
          child: Theme(
            data: _draftTheme(themeController.isDarkMode),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(AppStrings.settingsPreviewTitle).semiBold(),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text('Sample card').semiBold(),
                            const SizedBox(height: 4),
                            const Text(
                              'This is how cards, text, and buttons look with the settings above.',
                            ).muted(),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              children: [
                                Button(
                                  style: const ButtonStyle.primary(),
                                  onPressed: () {},
                                  child: const Text('Primary'),
                                ),
                                Button.outline(
                                  onPressed: () {},
                                  child: const Text('Outline'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
