import 'package:optic/helpers/appointment_tile.dart';
import 'package:optic/models/dashboard_appointment.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class AppointmentsColumn extends StatelessWidget {
  final DateTime selectedDate;
  final bool isToday;
  final List<DashboardAppointment> appointments;

  const AppointmentsColumn({
    super.key, 
    required this.selectedDate,
    required this.isToday,
    required this.appointments,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dateLabel = _formatDate(selectedDate);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Flexible(
              child: Text(
                isToday ? "Today's schedule" : 'Schedule',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ).semiBold(),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                '· $dateLabel',
                maxLines: 1,
                overflow: TextOverflow.fade,
              ).muted(),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (appointments.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.event_busy_outlined,
                      size: 28,
                      color: theme.colorScheme.mutedForeground,
                    ),
                    const SizedBox(height: 8),
                    Text('No appointments on this day').muted(),
                  ],
                ),
              ),
            ),
          )
        else
          Column(
            children: appointments
                .map(
                  (a) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: AppointmentTile(
                      appointment: a,
                      onStart: () {},
                      onOpenChart: () {},
                    ),
                  ),
                )
                .toList(),
          ),
      ],
    );
  }

  String _formatDate(DateTime d) {
    const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${weekdays[d.weekday - 1]}, ${months[d.month - 1]} ${d.day}';
  }
}
