/// Every user-facing piece of text used across the dashboard, sidebar, and
/// their widgets, in one place.
///
/// This is a plain static class for now — a stand-in so nothing in the UI
/// has a literal string baked into it. When you wire up your real language
/// file (e.g. via `intl`/`flutter_localizations`, or your own key/value
/// loader), the plan is:
///   - keep these same field names as the "keys" callers already use
///   - change each field from a hardcoded `String` to a lookup, e.g.
///     `static String get signOut => t('sidebar.sign_out');`
/// so none of the widgets below need to change, only this file does.
class AppStrings {
  AppStrings._();

  // --- Sidebar / nav -----------------------------------------------------
  static const String navDashboard = 'Dashboard';
  static const String navAppointments = 'Appointments';
  static const String navPatients = 'Patients';
  static const String navCalendar = 'Calendar';
  static const String navTasks = 'Tasks';
  static const String navSettings = 'Settings';
  static const String sidebarSignOut = 'Sign out';

  // --- Quick actions -------------------------------------------------------
  static const String quickActionNewAppointment = 'New appointment';
  static const String quickActionNewPatient = 'New patient';
  static const String quickActionStartTelemedicine = 'Start telemedicine';
  static const String quickActionWritePrescription = 'Write prescription';

  // --- KPI row -------------------------------------------------------------
  static const String kpiTodaysAppointments = "Today's appointments";
  static const String kpiCompleted = 'Completed';
  static const String kpiScheduled = 'Scheduled';
  static const String kpiCancelled = 'Cancelled';

  // --- Pending tasks panel --------------------------------------------------
  static const String pendingTasksTitle = 'Needs your attention';

  // --- Appointment tile: status labels ---------------------------------------
  // Matches the exact 3 values your real Appointment.status uses.
  static const String statusScheduled = 'Scheduled';
  static const String statusCompleted = 'Completed';
  static const String statusCancelled = 'Cancelled';

  // --- Appointment tile: action buttons --------------------------------------
  static const String actionStart = 'Start';
  static const String actionChart = 'Chart';

  // --- Placeholder screen ---------------------------------------------------
  static const String placeholderComingSoon = 'This screen is coming soon.';

  // --- Settings screen -------------------------------------------------------
  static const String settingsAppearanceTab = 'Appearance';
  static const String settingsAccountTab = 'Account';
  static const String settingsNotificationsTab = 'Notifications';
  static const String settingsColorSchemeLabel = 'Color scheme';
  static const String settingsDarkModeLabel = 'Dark mode';
  static const String settingsRadiusLabel = 'Corner radius';
  static const String settingsScalingLabel = 'UI scale';
  static const String settingsAccentColorLabel = 'Accent color';
  static const String settingsSurfaceOpacityLabel = 'Surface opacity';
  static const String settingsSurfaceBlurLabel = 'Surface blur';
  static const String settingsTypographyLabel = 'Use Geist typography';
  static const String settingsPreviewTitle = 'Preview';
  static const String settingsApplyButton = 'Apply theme';
  static const String settingsPreviewOnlyNote =
      'Dark mode applies immediately. Color, radius, scaling, and surface settings are preview-only for now.';
}
