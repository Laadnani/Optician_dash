import 'package:optic/data/data_provider.dart';
import '../models/dashboard_appointment.dart';
import '../models/pending_task.dart';

/// Where the dashboard's data comes from. `DashboardScreen` only ever talks
/// to this interface — swap the implementation and nothing in the UI needs
/// to change.
abstract class DashboardRepository {
  Future<List<DashboardAppointment>> fetchAppointments();
  Future<List<PendingTask>> fetchPendingTasks();
}

/// Backed by your real `DataProvider` (Patients/Appointments/etc., wired
/// through Provider). This is the "simple for now, real backend later"
/// bridge you asked for: once `DataProvider` itself talks to your API
/// instead of holding `mockPatients`/`mockAppointments` in memory, this
/// class doesn't need to change at all — it already just reads through
/// `DataProvider`.
class ProviderDashboardRepository implements DashboardRepository {
  final DataProvider dataProvider;

  const ProviderDashboardRepository(this.dataProvider);

  @override
  Future<List<DashboardAppointment>> fetchAppointments() async {
    final patientsById = {
      for (final patient in dataProvider.patients) patient.id: patient,
    };

    return dataProvider.appointments.map((appointment) {
      final patient = patientsById[appointment.patientId];
      final patientName = patient != null
          ? '${patient.firstName} ${patient.lastName}'
          : 'Unknown patient';

      return DashboardAppointment(
        id: appointment.id,
        patientId: appointment.patientId,
        patientName: patientName,
        start: appointment.date,
        doctor: appointment.doctor,
        reason: appointment.reason,
        status: _mapStatus(appointment.status),
      );
    }).toList();
  }

  AppointmentStatus _mapStatus(String raw) {
    switch (raw) {
      case 'completed':
        return AppointmentStatus.completed;
      case 'cancelled':
        return AppointmentStatus.cancelled;
      case 'scheduled':
      default:
        // Falls back to "scheduled" for any unrecognized value rather than
        // throwing, since `Appointment.status` is a plain String (not an
        // enum) and could carry an unexpected value from a future backend.
        return AppointmentStatus.scheduled;
    }
  }

  // NOTE: your models/lab_order.dart, imaging_order.dart, referral.dart,
  // and inventory.dart weren't shared yet, so "pending tasks" (labs
  // awaiting review, imaging results, low stock, etc.) still can't be
  // derived from real data — this stays as placeholder content for now.
  // Share those model shapes and this becomes a real derivation, same
  // pattern as fetchAppointments above.
  @override
  Future<List<PendingTask>> fetchPendingTasks() async {
    return const [
      PendingTask(
        title: 'Pending tasks aren\'t wired to real data yet',
        subtitle: 'Share lab_order.dart / imaging_order.dart / referral.dart / inventory.dart to wire this up',
        kind: PendingTaskKind.labResult, 
        id: '', 
        sourceId: '',
      ),
    ];
  }
}
