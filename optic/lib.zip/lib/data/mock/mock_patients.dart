import '../../models/patient.dart';
import '../../models/appointment.dart';
import '../../models/eye_exam.dart';
import '../../models/prescription.dart';
import '../../models/billing.dart';
import '../../models/payments.dart';
import '../../models/report.dart';
import '../../models/medical_history.dart';
import '../../models/allergy.dart';
import '../../models/soap_note.dart';
import '../../models/diagnosis.dart';
import '../../models/imaging_order.dart';
import '../../models/insurance.dart';
import '../../models/document.dart';
import '../../models/digital_signature.dart';
import '../../models/referral.dart';
import '../../models/inventory.dart';
import '../../models/vital_signs.dart';
import '../../models/lab_order.dart';
import '../../models/dicom_file.dart';

/// Patients
final List<Patient> mockPatients = [
  Patient(
    id: "P001",
    fileNumber: "F001",
    nationalId: "NID001",
    firstName: "Karim",
    lastName: "Hafidy",
    dob: DateTime(1985, 6, 12),
    gender: "Male",
    bloodGroup: "A+",
    phone: "+212600000001",
    email: "karim.hafidy@example.com",
    insurance: "CNOPS",
  ),
  Patient(
    id: "P002",
    fileNumber: "F002",
    nationalId: "NID002",
    firstName: "Sara",
    lastName: "Benali",
    dob: DateTime(2005, 3, 25),
    gender: "Female",
    bloodGroup: "O-",
    phone: "+212600000002",
    email: "sara.benali@example.com",
    insurance: "",
  ),
];

/// Appointments
final List<Appointment> mockAppointments = [
  Appointment(
    id: "A001",
    patientId: "P001",
    date: DateTime(2026, 7, 28, 10, 0),
    doctor: "Dr. Ahmed",
    reason: "Routine eye check",
    status: "scheduled",
  ),
];

/// Eye Exams
final List<EyeExam> mockEyeExams = [
  EyeExam(
    id: "E001",
    patientId: "P001",
    examDate: DateTime(2026, 7, 28),
    visualAcuity: "20/20",
    sph: -1.25,
    cyl: -0.50,
    axis: 90,
    notes: "Mild myopia, prescription updated.",
  ),
];

/// Prescriptions
final List<Prescription> mockPrescriptions = [
  Prescription(
    id: "PR001",
    patientId: "P001",
    date: DateTime(2026, 7, 28),
    medications: ["Eyedrops: Timolol", "Glasses: -1.25 SPH"],
    instructions: "Use eyedrops twice daily, wear glasses full-time.",
  ),
];

/// Billing & Invoices
final List<Invoice> mockInvoices = [
  Invoice(
    id: "INV001",
    patientId: "P001",
    date: DateTime(2026, 7, 28),
    amount: 500.0,
    status: "paid",
  ),
];

/// Payments
final List<Payment> mockPayments = [
  Payment(
    id: "PAY001",
    invoiceId: "INV001",
    date: DateTime(2026, 7, 28),
    amount: 500.0,
    method: "card",
  ),
];

/// Reports
final List<Report> mockReports = [
  Report(
    id: "R001",
    type: "clinical",
    generatedAt: DateTime(2026, 7, 28),
    filePath: "/reports/clinical_r001.pdf",
  ),
];

/// Medical History
final List<MedicalHistory> mockHistories = [
  MedicalHistory(
    id: "MH001",
    patientId: "P001",
    conditions: ["Myopia"],
    surgeries: [],
    familyHistory: ["Glaucoma"],
    notes: "Patient has mild myopia.",
  ),
];

/// Allergies
final List<Allergy> mockAllergies = [
  Allergy(
    id: "AL001",
    patientId: "P002",
    allergen: "Dust",
    reaction: "Sneezing",
    severity: "Mild",
  ),
];

/// SOAP Notes
final List<SoapNote> mockSoapNotes = [
  SoapNote(
    id: "SN001",
    patientId: "P001",
    date: DateTime(2026, 7, 28),
    subjective: "Blurred vision",
    objective: "20/40 acuity",
    assessment: "Myopia",
    plan: "Prescribe glasses",
  ),
];

/// Diagnoses
final List<Diagnosis> mockDiagnoses = [
  Diagnosis(
    id: "D001",
    patientId: "P001",
    date: DateTime(2026, 7, 28),
    icdCode: "H52.1",
    description: "Myopia",
  ),
];

/// Imaging Orders
final List<ImagingOrder> mockImagingOrders = [
  ImagingOrder(
    id: "IO001",
    patientId: "P001",
    orderDate: DateTime(2026, 7, 28),
    modality: "OCT",
    reason: "Retina check",
    status: "pending",
  ),
];

/// Insurance
final List<Insurance> mockInsurances = [
  Insurance(
    id: "INS001",
    patientId: "P001",
    provider: "CNOPS",
    policyNumber: "POL123",
    validUntil: DateTime(2027, 7, 28),
  ),
];

/// Documents
final List<DocumentRecord> mockDocuments = [
  DocumentRecord(
    id: "DOC001",
    patientId: "P001",
    type: "Consent Form",
    filePath: "/docs/consent_p001.pdf",
    uploadedAt: DateTime(2026, 7, 28),
  ),
];

/// Digital Signatures
final List<DigitalSignature> mockSignatures = [
  DigitalSignature(
    id: "SIG001",
    doctorId: "DR001",
    patientId: "P001",
    signedAt: DateTime(2026, 7, 28),
    signatureData: "base64signaturedata",
  ),
];

/// Referrals
final List<Referral> mockReferrals = [
  Referral(
    id: "REF001",
    patientId: "P001",
    referredTo: "Dr. Leila",
    reason: "Specialist consultation",
    date: DateTime(2026, 7, 29),
  ),
];

/// Inventory
final List<InventoryItem> mockInventory = [
  InventoryItem(
    id: "INV001",
    name: "Eyedrops",
    quantity: 50,
    unit: "bottles",
    lastUpdated: DateTime(2026, 7, 25),
  ),
];

/// Vital Signs
final List<VitalSign> mockVitalSigns = [
  VitalSign(
    id: "VS001",
    patientId: "P001",
    recordedAt: DateTime(2026, 7, 28),
    temperature: 36.8,
    heartRate: 72,
    systolicBP: 120,
    diastolicBP: 80,
  ),
];

/// Lab Orders
final List<LabOrder> mockLabOrders = [
  LabOrder(
    id: "LAB001",
    patientId: "P001",
    orderDate: DateTime(2026, 7, 28),
    testName: "Blood Sugar",
    status: "completed",
  ),
];

/// DICOM Files
final List<DicomFile> mockDicomFiles = [
  DicomFile(
    id: "DCM001",
    patientId: "P001",
    filePath: "/dicom/oct_p001.dcm",
    uploadedAt: DateTime(2026, 7, 28),
    modality: "OCT",
  ),
];
