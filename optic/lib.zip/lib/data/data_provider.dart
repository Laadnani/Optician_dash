import 'package:flutter/material.dart';
import 'package:optic/data/mock/mock_patients.dart';
import '../models/patient.dart';
import '../models/appointment.dart';
import '../models/eye_exam.dart';
import '../models/prescription.dart';
import '../models/billing.dart';
import '../models/payments.dart';
import '../models/report.dart';
import '../models/medical_history.dart';
import '../models/allergy.dart';
import '../models/soap_note.dart';
import '../models/diagnosis.dart';
import '../models/imaging_order.dart';
import '../models/insurance.dart';
import '../models/document.dart';
import '../models/digital_signature.dart';
import '../models/referral.dart';
import '../models/inventory.dart';
import '../models/vital_signs.dart';
import '../models/lab_order.dart';
import '../models/dicom_file.dart';

class DataProvider extends ChangeNotifier {
  final List<Patient> patients = [...mockPatients]; // Mock data for testing
  final List<Appointment> appointments = [...mockAppointments]; // Mock data for testing
  final List<EyeExam> eyeExams = [];
  final List<Prescription> prescriptions = [];
  final List<Invoice> invoices = [];
  final List<Payment> payments = [];
  final List<Report> reports = [];
  final List<MedicalHistory> histories = [];
  final List<Allergy> allergies = [];
  final List<SoapNote> soapNotes = [];
  final List<Diagnosis> diagnoses = [];
  final List<ImagingOrder> imagingOrders = [];
  final List<Insurance> insurances = [];
  final List<DocumentRecord> documents = [];
  final List<DigitalSignature> signatures = [];
  final List<Referral> referrals = [];
  final List<InventoryItem> inventory = [];
  final List<VitalSign> vitalSigns = [];
  final List<LabOrder> labOrders = [];
  final List<DicomFile> dicomFiles = [];

  // Example add methods
  void addPatient(Patient patient) {
    patients.add(patient);
    notifyListeners();
  }

  void addAppointment(Appointment appointment) {
    appointments.add(appointment);
    notifyListeners();
  }

  void addEyeExam(EyeExam exam) {
    eyeExams.add(exam);
    notifyListeners();
  }
}
