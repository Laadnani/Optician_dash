import 'package:flutter/material.dart';

/// Controls theme mode (light/dark).
class ThemeController extends ChangeNotifier {
  bool _isDarkMode = true;

  bool get isDarkMode => _isDarkMode;

  /// Toggle between dark and light mode
  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  /// Explicitly set theme mode
  void setTheme(bool darkMode) {
    _isDarkMode = darkMode;
    notifyListeners();
  }
}
