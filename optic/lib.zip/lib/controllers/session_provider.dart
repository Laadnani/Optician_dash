/// Stand-in for the signed-in doctor's profile / clinic info, shown in the
/// sidebar. Replace with your real auth/profile data source (or a
/// `ValueListenable`/stream if it can change at runtime) — the sidebar
/// only reads from here, so this is the one file that needs to change.
class SessionProvider {
  SessionProvider._();
 
  // TODO: wire to your real session/profile data layer.
  static String get clinicName => '';
  static String get doctorName => '';
}
