// main.dart

import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:optic/helpers/nav_items.dart';
import 'package:provider/provider.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

import 'constants.dart';
import 'controllers/menu_app_controller.dart';
import 'controllers/theme_controller.dart';
import 'data/data_provider.dart';
import 'localization/app_strings.dart';
import 'screens/dashboard_screen.dart';
import 'screens/placeholder_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  // Single runApp call. MultiProvider has to be the outermost widget so
  // MenuAppController/DataProvider/ThemeController are available to every
  // routed screen (they live above the Router, not inside it) — that's
  // the one thing the doc's flat `runApp(ShadcnApp(...))` example doesn't
  // need to account for, since it has no providers at all.
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MenuAppController()),
        ChangeNotifierProvider(create: (_) => DataProvider()),
        ChangeNotifierProvider(create: (_) => ThemeController()),
      ],
      child: const _App(),
    ),
  );
}

/// The actual ShadcnApp root — kept as its own widget (rather than inlined
/// in `main()`) only so it can read ThemeController via Consumer. This is
/// the single `ShadcnApp` in the whole tree.
class _App extends StatelessWidget {
  const _App();

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeController>(
      builder: (context, themeController, _) {
        return ShadcnApp.router(
          debugShowCheckedModeBanner: false,
          title: 'Doc CRM',
          scaling: const AdaptiveScaling(0.85),
          theme: ThemeData(
            colorScheme: themeController.isDarkMode
                ? ColorSchemes.darkDefaultColor
                : ColorSchemes.lightDefaultColor,
            radius: 1.5,
            surfaceOpacity: 0.8,
            surfaceBlur: 8,
          ),
          routerConfig: GoRouter(
            initialLocation: NavRoute.dashboard.path,
            routes: [
              GoRoute(
                path: NavRoute.dashboard.path,
                builder: (context, state) => const DashboardScreen(),
              ),
              GoRoute(
                path: NavRoute.appointments.path,
                builder: (context, state) => const PlaceholderScreen(
                  title: AppStrings.navAppointments,
                  navRoute: NavRoute.appointments,
                ),
              ),
              GoRoute(
                path: NavRoute.patients.path,
                builder: (context, state) => const PlaceholderScreen(
                  title: AppStrings.navPatients,
                  navRoute: NavRoute.patients,
                ),
              ),
              GoRoute(
                path: NavRoute.calendar.path,
                builder: (context, state) => const PlaceholderScreen(
                  title: AppStrings.navCalendar,
                  navRoute: NavRoute.calendar,
                ),
              ),
              GoRoute(
                path: NavRoute.tasks.path,
                builder: (context, state) => const PlaceholderScreen(
                  title: AppStrings.navTasks,
                  navRoute: NavRoute.tasks,
                ),
              ),
              GoRoute(
                path: NavRoute.settings.path,
                builder: (context, state) => const SettingsScreen(),
              ),
            ],
          ),
        );
      },
    );
  }
}
