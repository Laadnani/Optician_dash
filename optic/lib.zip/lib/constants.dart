// lib/constants.dart
import 'package:flutter/material.dart';

// Background color for scaffold
const Color bgColor = Color(0xFF212332);

// Secondary color for canvas
const Color secondaryColor = Color(0xFF2A2D3E);

// You can also define other constants here (padding, default duration, etc.)
const double defaultPadding = 16.0;
