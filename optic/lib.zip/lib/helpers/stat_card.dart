import 'package:shadcn_flutter/shadcn_flutter.dart';

/// A compact KPI tile, e.g. "Today's patients: 12".
///
/// Flat leading-icon + text layout. Text readability is the priority:
///  - the icon stays modest-sized so it doesn't eat into the text column's
///    width
///  - the text column gets `Expanded` + `start` alignment (not `stretch`,
///    and no `.expanded()` on the label itself — wrapping a `Text` in its
///    own `Expanded` inside a `mainAxisSize.max` Column is what was forcing
///    the label into a tall, narrow strip instead of reading left-to-right)
///  - font sizes still scale with the card's width, but are clamped to a
///    readable floor/ceiling so they never shrink to illegible or blow up
///    too large
class DashboardStatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color accent;

  const DashboardStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.accent,
  });

  // Reference width this design was tuned at. Scale is 1.0 here; it grows
  // above that on wider cards and shrinks below it on narrower ones.
  static const double _referenceWidth = 220;
  static const double _minScale = 0.85;
  static const double _maxScale = 1.2;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth.isFinite
                ? constraints.maxWidth
                : _referenceWidth;
            final scale = (width / _referenceWidth).clamp(
              _minScale,
              _maxScale,
            );

            // Readable floor/ceiling regardless of scale.
            final valueSize = (18 * scale).clamp(15.0, 22.0);
            final labelSize = (13 * scale).clamp(11.5, 15.0);

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(icon, color: accent, size: 22 * scale),
                SizedBox(width: 12 * scale),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        value,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: valueSize),
                      ).bold(),
                      const SizedBox(height: 2),
                      Text(
                        label,
                        maxLines: 2,
                        softWrap: true,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: labelSize, height: 1.25),
                      ).muted(),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
