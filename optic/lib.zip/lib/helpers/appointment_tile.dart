import 'package:shadcn_flutter/shadcn_flutter.dart';
import '../models/dashboard_appointment.dart';
import '../localization/app_strings.dart';
import 'status_chip.dart';

class AppointmentTile extends StatelessWidget {
  final DashboardAppointment appointment;
  final VoidCallback? onStart;
  final VoidCallback? onOpenChart;

  const AppointmentTile({
    super.key,
    required this.appointment,
    this.onStart,
    this.onOpenChart,
  });

  // Below this width there isn't room for time + divider + avatar + name
  // + status chip + action button all in one Row — the trailing
  // status/action group drops to its own line instead of forcing an
  // overflow.
  static const double _compactBreakpoint = 420;

  Color _statusColor(ColorScheme colors) {
    switch (appointment.status) {
      case AppointmentStatus.scheduled:
        return colors.primary;
      case AppointmentStatus.completed:
        return Colors.green.shade700;
      case AppointmentStatus.cancelled:
        return colors.destructive;
    }
  }

  String _statusLabel() {
    switch (appointment.status) {
      case AppointmentStatus.scheduled:
        return AppStrings.statusScheduled;
      case AppointmentStatus.completed:
        return AppStrings.statusCompleted;
      case AppointmentStatus.cancelled:
        return AppStrings.statusCancelled;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _statusColor(theme.colorScheme);
    final timeFmt = TimeOfDay.fromDateTime(appointment.start);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isCompact = constraints.maxWidth < _compactBreakpoint;

            final timeBlock = SizedBox(
              width: 56,
              child: Text(
                '${timeFmt.hour}:${timeFmt.minute.toString().padLeft(2, '0')}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ).semiBold(),
            );

            final patientBlock = Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appointment.patientName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ).semiBold(),
                  const SizedBox(height: 2),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.notes_outlined,
                        size: 14,
                        color: theme.colorScheme.mutedForeground,
                      ),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          // reason falls back to the doctor's name if it's
                          // empty, so the line is never blank.
                          appointment.reason.isNotEmpty
                              ? appointment.reason
                              : appointment.doctor,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ).muted(),
                      ),
                    ],
                  ),
                ],
              ),
            );

            final actionButton = appointment.status == AppointmentStatus.scheduled
                ? Button.outline(
                    onPressed: onStart,
                    leading: const Icon(Icons.play_arrow_outlined, size: 12),
                    child: const Text(
                      AppStrings.actionStart,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                : Button.outline(
                    onPressed: onOpenChart,
                    child: const Text(
                      AppStrings.actionChart,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );

            final statusAndAction = isCompact
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      StatusChip(label: _statusLabel(), color: statusColor),
                      const SizedBox(height: 6),
                      actionButton,
                    ],
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      StatusChip(label: _statusLabel(), color: statusColor),
                      const SizedBox(width: 8),
                      actionButton,
                    ],
                  );

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                timeBlock,
                Container(
                  width: 1,
                  height: 40,
                  color: theme.colorScheme.border,
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                ),
                Avatar(
                  initials: appointment.patientName.isNotEmpty
                      ? appointment.patientName.substring(0, 1).toUpperCase()
                      : '?',
                ),
                const SizedBox(width: 12),
                patientBlock,
                const SizedBox(width: 8),
                statusAndAction,
              ],
            );
          },
        ),
      ),
    );
  }
}
