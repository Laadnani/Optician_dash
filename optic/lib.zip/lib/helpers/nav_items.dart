import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:optic/widgets/sidebar.dart';
import 'package:optic/localization/app_strings.dart';

/// Stable routing/selection identity for each nav destination — separate
/// from its *display* label, so selection/navigation keeps working once
/// labels come from a language file (a translated label is a different
/// string per locale; this enum value never changes).
enum NavRoute { dashboard, appointments, patients, calendar, tasks, settings }

/// The URL path each route maps to. Single source of truth for both the
/// GoRouter config (`routing/app_router.dart`) and anything that needs to
/// navigate there.
extension NavRoutePath on NavRoute {
  String get path {
    switch (this) {
      case NavRoute.dashboard:
        return '/';
      case NavRoute.appointments:
        return '/appointments';
      case NavRoute.patients:
        return '/patients';
      case NavRoute.calendar:
        return '/calendar';
      case NavRoute.tasks:
        return '/tasks';
      case NavRoute.settings:
        return '/settings';
    }
  }
}

/// One shared nav list, used by both the desktop sidebar and the
/// mobile/tablet overlay drawer, on every screen. [currentRoute] marks
/// which entry is "selected"; tapping any other entry navigates there via
/// GoRouter.
List<DrawerItem> buildAppNavItems(BuildContext context, NavRoute currentRoute) {
  void goTo(NavRoute route) {
    if (route == currentRoute) return; // already here
    context.go(route.path);
  }

  return [
    DrawerItem(
      label: AppStrings.navDashboard,
      icon: Icons.dashboard_outlined,
      selected: currentRoute == NavRoute.dashboard,
      onTap: () => goTo(NavRoute.dashboard),
    ),
    DrawerItem(
      label: AppStrings.navAppointments,
      icon: Icons.event_available_outlined,
      selected: currentRoute == NavRoute.appointments,
      onTap: () => goTo(NavRoute.appointments),
    ),
    DrawerItem(
      label: AppStrings.navPatients,
      icon: Icons.people_outline,
      selected: currentRoute == NavRoute.patients,
      onTap: () => goTo(NavRoute.patients),
    ),
    DrawerItem(
      label: AppStrings.navCalendar,
      icon: Icons.calendar_month_outlined,
      selected: currentRoute == NavRoute.calendar,
      onTap: () => goTo(NavRoute.calendar),
    ),
    DrawerItem(
      label: AppStrings.navTasks,
      icon: Icons.checklist_outlined,
      selected: currentRoute == NavRoute.tasks,
      onTap: () => goTo(NavRoute.tasks),
    ),
    DrawerItem(
      label: AppStrings.navSettings,
      icon: Icons.settings_outlined,
      selected: currentRoute == NavRoute.settings,
      onTap: () => goTo(NavRoute.settings),
    ),
  ];
}
