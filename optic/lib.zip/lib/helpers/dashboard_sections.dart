import 'package:optic/app_shell.dart';
import 'package:optic/helpers/breakpoint.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

/// Arranges the three main cards (calendar / appointments / pending tasks)
/// for a given [breakpoint]. This is the ONLY place that decides "who goes
/// next to whom" — the cards themselves are built elsewhere and just get
/// slotted in here, so this file never needs to know what's inside them.
class DashboardMainSection extends StatelessWidget {
  final Breakpoint breakpoint;
  final Widget calendarCard;
  final Widget appointmentsCard;
  final Widget pendingTasksCard;

  const DashboardMainSection({
    super.key,
    required this.breakpoint,
    required this.calendarCard,
    required this.appointmentsCard,
    required this.pendingTasksCard,
  });

  @override
  Widget build(BuildContext context) {
    switch (breakpoint) {
      case Breakpoint.desktop:
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 3, child: calendarCard),
            const SizedBox(width: 16),
            Expanded(flex: 4, child: appointmentsCard),
            const SizedBox(width: 16),
            Expanded(flex: 3, child: pendingTasksCard),
          ],
        );

      case Breakpoint.tablet:
        // Tablet currently shares the stacked layout with mobile, but has
        // its own case so it can be customized independently later
        // without touching the mobile or desktop cases.
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            calendarCard,
            const SizedBox(height: 16),
            appointmentsCard,
            const SizedBox(height: 16),
            pendingTasksCard,
          ],
        );

      case Breakpoint.mobile:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            calendarCard,
            const SizedBox(height: 16),
            appointmentsCard,
            const SizedBox(height: 16),
            pendingTasksCard,
          ],
        );
    }
  }
}