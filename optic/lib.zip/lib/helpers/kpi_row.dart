import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'stat_card.dart';
import '../localization/app_strings.dart';

/// The 4-tile KPI row ("Today's appointments" / "Completed" / "Scheduled" /
/// "Cancelled" — matching the 3 real Appointment.status values, plus the
/// day's total). Isolated so it — and the [DashboardStatCard] tiles inside
/// it — can be tweaked without touching the rest of the dashboard.
class DashboardKpiRow extends StatelessWidget {
  final bool desktop;
  final int todaysCount;
  final int completed;
  final int scheduled;
  final int cancelled;

  const DashboardKpiRow({
    super.key,
    required this.desktop,
    required this.todaysCount,
    required this.completed,
    required this.scheduled,
    required this.cancelled,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 4,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: desktop ? 3 : 1,
      children: [
        DashboardStatCard(
          label: AppStrings.kpiTodaysAppointments,
          value: '$todaysCount',
          icon: Icons.calendar_today_outlined,
          accent: ColorSchemes.lightDefaultColor.chart2,
        ),
        DashboardStatCard(
          label: AppStrings.kpiCompleted,
          value: '$completed',
          icon: Icons.check_circle_outline,
          accent: Colors.green.shade700,
        ),
        DashboardStatCard(
          label: AppStrings.kpiScheduled,
          value: '$scheduled',
          icon: Icons.schedule_outlined,
          accent: Colors.orange.shade700,
        ),
        DashboardStatCard(
          label: AppStrings.kpiCancelled,
          value: '$cancelled',
          icon: Icons.cancel_outlined,
          accent: ColorSchemes.lightDefaultColor.chart3,
        ),
      ],
    );
  }
}
