import 'package:shadcn_flutter/shadcn_flutter.dart';
import '../models/pending_task.dart';

class PendingTasksPanel extends StatelessWidget {
  final String title;
  final List<PendingTask> items;
  final VoidCallback? onSeeAll;

  /// Optional: called when a task row itself is tapped (not "See all").
  /// Wire this to navigate to the task's source record via
  /// `item.sourceId`/`item.kind` once those detail screens exist.
  final void Function(PendingTask item)? onTapItem;

  const PendingTasksPanel({
    super.key,
    required this.title,
    required this.items,
    this.onSeeAll,
    this.onTapItem,
  });

  /// Icon + color for a task's kind, in one place instead of two separate
  /// switches. Still a real `switch` (not a lookup map) so the compiler
  /// forces every new [PendingTaskKind] case to be handled here too.
  (IconData, Color) _styleFor(PendingTaskKind kind, ColorScheme colors) {
    switch (kind) {
      case PendingTaskKind.labResult:
        return (Icons.science_outlined, Colors.purple.shade400);
      case PendingTaskKind.imagingResult:
        return (Icons.image_search_outlined, Colors.blue.shade400);
      case PendingTaskKind.referral:
        return (Icons.call_made_outlined, Colors.teal.shade400);
      case PendingTaskKind.lowStock:
        return (Icons.inventory_2_outlined, colors.destructive);
      case PendingTaskKind.signature:
        return (Icons.draw_outlined, Colors.orange.shade600);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title).semiBold(),
                if (onSeeAll != null)
                  Button.link(onPressed: onSeeAll, child: const Text('See all')),
              ],
            ),
            const SizedBox(height: 4),
            if (items.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Nothing pending — you\'re all caught up.').muted(),
              )
            else
              ...items.map((item) {
                final (icon, color) = _styleFor(item.kind, theme.colorScheme);
                final row = Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(icon, size: 18, color: color),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.title).small(),
                            Text(item.subtitle).muted(),
                          ],
                        ),
                      ),
                    ],
                  ),
                );

                if (onTapItem == null) return row;
                return GestureDetector(
                  onTap: () => onTapItem!(item),
                  child: row,
                );
              }),
          ],
        ),
      ),
    );
  }
}
